
 This directory contains the beginnings of a set of tests suites for fpGUI.
 Over time the test suite will be extended to cover many parts of CoreLib 
 and the GUI components.

  Reguirements:
    * Lazarus IDE
    * guitestrunner_fpgui.lpk package
    * tiOPFfpGUI.lpk package - tiOPF is available on SourceForge. This
          requirement is due to the MGM mediator implementation.

Graeme.



