
  To create an animation bitmap you need to place the different
  frames in a horizontal layout. Each frame must be the same size.
  I included the original gears.xcf file which can be edited with 
  'The Gimp' imaging program.
  
  This demo includes two animation examples.
  
    gears.bmp - which contains 4 frames with transparency.
    wanda.bmp - which contains 8 frames and no transparency.
                Wanda the fish originates from the Gnome project.
		
		
  Regards,
    - Graeme -
