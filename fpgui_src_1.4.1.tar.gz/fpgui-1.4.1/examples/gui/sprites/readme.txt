
This was a quick port of the Lazarus Sprites demo. It was simply out of
curiosity to see how it would work under fpGUI. It actually works better
than under Lazarus LCL! :-)

Keyboard controls available in the demo:
  d    - enable debug mode (currently shows the timer interval)
  PgUp - increments the timer interval (jumpy animation)
  PgDn - decrements the timer interval (smoother animation)
  Esc  - quits the application

   ----------  END  -------------


