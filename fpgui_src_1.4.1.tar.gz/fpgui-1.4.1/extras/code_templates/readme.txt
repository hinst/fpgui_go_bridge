
fpGUI Code Templates
--------------------

This is a directory where you will find fpGUI Code Templates for use with 
the Lazarus IDE.


1) Open the template you want to add to Lazurus. For example basicapp.txt

2) Open the lazarus.dci file with you favourite editor. This is the file that
   Lazarus uses to store all code templates.  The location of 
   the lararus.dci is normally as follows:

  Linux:
    /home/<your user name>/.lazarus/lazarus.dci

3) Copy all the text from the template file you opened in (1).

4) Move to the end of the lazarus.dci file you opened in (2) and paste the 
   text from the clipboard.

5) Save the lazarus.dci file and you are ready to go!


           -----------.oO0Oo.-----------

