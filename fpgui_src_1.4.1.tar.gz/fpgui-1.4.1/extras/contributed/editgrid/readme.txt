
Name:    EditGrid widget
Author:  Jean-Marc Levecque <jmarc.levecque@jmlesite.fr>
Date:    2013
Description:
Inspired by the grid editing demo, the idea then came to make an
editgrid which would incorporate existing edit components. Included
here is the editgrid widget, and a demo project. This is still work
in progress.

