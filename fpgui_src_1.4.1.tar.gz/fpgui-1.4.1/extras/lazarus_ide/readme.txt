
fpgui_ide.lpk
  This package adds a new project type in the Lazarus IDE.
  So you can then create a fpGUI based project by 
  going: 'File | New' and selecting 'fpGUI Application'.

idefpguitestrunner.lpk
  This package adds a new project type in the Lazarus IDE.
  So you can new create FPCUnit test projects using the
  fpGUI toolkit as front-end.


  Regards,
    Graeme.

