This directory contains a zipped copy of the freetype.dll file. This is
required if you use the Agg enabled Canvas, and have the FreeType font
engine enabled.

The FreeType font engine has more functionality and better looking output
than the Win32 font engine.

Regards,
  Graeme.

