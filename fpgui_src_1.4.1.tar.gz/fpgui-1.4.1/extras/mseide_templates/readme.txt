
Project Template for MSEide
----------------------------

   To use it, copy the project template to the usual
   MSEide templates directory, or use if from where
   it is - inside fpGUI directory.
   "Project > New > From Template" then browse to
   fpGUI directory and select the "fpgui.prj" file.

   Under "Project > Options > Macros" you need to update
   the path to where fpGUI is located on your system.


     -------------- end -----------------


