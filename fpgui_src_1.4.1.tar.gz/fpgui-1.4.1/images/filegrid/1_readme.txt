
These images are for future use.  I would like to expand the 
filegrid class to support image types instead of the standard
single icon for all files.

At the momement fpGUI doesn't support PNG images. So they might
need to be converted to BMP before we can use them. Alternatively
PNG image support must be added to fpGUI.

Graeme.

