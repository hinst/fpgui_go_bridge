The code found here is optional extras. When using them, they will add
extra dependencies to your project, but that is a choice for you to
make.

For further details please see the README file in each sub-directory.